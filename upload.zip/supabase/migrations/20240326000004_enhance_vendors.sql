-- Create vendor categories enum
CREATE TYPE public.vendor_category AS ENUM (
    'venue',
    'catering',
    'entertainment',
    'decor',
    'attire',
    'transportation',
    'planning',
    'other'
);

-- Add new columns to vendors table
ALTER TABLE public.vendors
ADD COLUMN IF NOT EXISTS category vendor_category NOT NULL DEFAULT 'other',
ADD COLUMN IF NOT EXISTS contact_name TEXT,
ADD COLUMN IF NOT EXISTS contact_email TEXT,
ADD COLUMN IF NOT EXISTS contact_phone TEXT,
ADD COLUMN IF NOT EXISTS address TEXT,
ADD COLUMN IF NOT EXISTS city TEXT,
ADD COLUMN IF NOT EXISTS state TEXT,
ADD COLUMN IF NOT EXISTS zip TEXT,
ADD COLUMN IF NOT EXISTS website TEXT,
ADD COLUMN IF NOT EXISTS social_media JSONB,
ADD COLUMN IF NOT EXISTS services TEXT[],
ADD COLUMN IF NOT EXISTS pricing_range TEXT,
ADD COLUMN IF NOT EXISTS availability JSONB,
ADD COLUMN IF NOT EXISTS rating DECIMAL(3,2),
ADD COLUMN IF NOT EXISTS reviews_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS is_featured BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS portfolio_url TEXT,
ADD COLUMN IF NOT EXISTS insurance_info TEXT,
ADD COLUMN IF NOT EXISTS contract_template TEXT;

-- Create wedding_vendor_services table for specific services provided for each wedding
CREATE TABLE IF NOT EXISTS public.wedding_vendor_services (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    wedding_vendor_id UUID NOT NULL REFERENCES public.wedding_vendors(id) ON DELETE CASCADE,
    service_name TEXT NOT NULL,
    description TEXT,
    price DECIMAL(10,2),
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled')),
    scheduled_date TIMESTAMP WITH TIME ZONE,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable Row Level Security
ALTER TABLE public.wedding_vendor_services ENABLE ROW LEVEL SECURITY;

-- Create policies for wedding_vendor_services
CREATE POLICY "Enable read access for all users" ON public.wedding_vendor_services
    FOR SELECT USING (true);

CREATE POLICY "Enable insert for authenticated users only" ON public.wedding_vendor_services
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Enable update for authenticated users only" ON public.wedding_vendor_services
    FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Enable delete for authenticated users only" ON public.wedding_vendor_services
    FOR DELETE USING (auth.role() = 'authenticated');

-- Create updated_at trigger for wedding_vendor_services
CREATE TRIGGER handle_wedding_vendor_services_updated_at
    BEFORE UPDATE ON public.wedding_vendor_services
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

-- Add vendor reviews table
CREATE TABLE IF NOT EXISTS public.vendor_reviews (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    vendor_id UUID NOT NULL REFERENCES public.vendors(id) ON DELETE CASCADE,
    wedding_id UUID NOT NULL REFERENCES public.weddings(id) ON DELETE CASCADE,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    review_text TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(vendor_id, wedding_id)
);

-- Enable Row Level Security
ALTER TABLE public.vendor_reviews ENABLE ROW LEVEL SECURITY;

-- Create policies for vendor_reviews
CREATE POLICY "Enable read access for all users" ON public.vendor_reviews
    FOR SELECT USING (true);

CREATE POLICY "Enable insert for authenticated users only" ON public.vendor_reviews
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Enable update for authenticated users only" ON public.vendor_reviews
    FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Enable delete for authenticated users only" ON public.vendor_reviews
    FOR DELETE USING (auth.role() = 'authenticated');

-- Create updated_at trigger for vendor_reviews
CREATE TRIGGER handle_vendor_reviews_updated_at
    BEFORE UPDATE ON public.vendor_reviews
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at(); 