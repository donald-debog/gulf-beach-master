-- Add wedding_id column to clients table
ALTER TABLE clients
ADD COLUMN wedding_id UUID REFERENCES weddings(id) ON DELETE SET NULL;

-- Create index for better query performance
CREATE INDEX idx_clients_wedding_id ON clients(wedding_id);

-- Add RLS policies for the wedding relationship
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view clients with their weddings"
  ON clients FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert clients with their weddings"
  ON clients FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update clients with their weddings"
  ON clients FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete clients with their weddings"
  ON clients FOR DELETE
  USING (auth.uid() = user_id); 