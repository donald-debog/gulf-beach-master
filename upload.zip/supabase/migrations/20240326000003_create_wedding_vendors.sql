-- Create wedding_vendors junction table
CREATE TABLE IF NOT EXISTS public.wedding_vendors (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    wedding_id UUID NOT NULL REFERENCES public.weddings(id) ON DELETE CASCADE,
    vendor_id UUID NOT NULL REFERENCES public.vendors(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(wedding_id, vendor_id)
);

-- Enable Row Level Security
ALTER TABLE public.wedding_vendors ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for all users" ON public.wedding_vendors
    FOR SELECT USING (true);

CREATE POLICY "Enable insert for authenticated users only" ON public.wedding_vendors
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Enable update for authenticated users only" ON public.wedding_vendors
    FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Enable delete for authenticated users only" ON public.wedding_vendors
    FOR DELETE USING (auth.role() = 'authenticated');

-- Create updated_at trigger
CREATE TRIGGER handle_wedding_vendors_updated_at
    BEFORE UPDATE ON public.wedding_vendors
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at(); 