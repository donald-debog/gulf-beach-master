import BlogPostEditor from "../[id]/page";

export default function NewBlogPostPage() {
  return <BlogPostEditor />;
} 