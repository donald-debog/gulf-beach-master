export default function ClientDetailPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Client Details</h1>
      <p className="text-gray-600">This is the client detail/edit page. Build out the form and details here.</p>
    </div>
  );
} 